---
layout: author
photo: /assets/img/uploads/profile.png
name: mranderson
display_name: Mr. Anderson
position: The One
bio: Bulletproof hacker passionate about leather clothes.
github_username: github_username
facebook_username: facebook_username
twitter_username: twitter_username
instagram_username: instagram_username
linkedin_username: linkedin_username
medium_username: medium_username
---

